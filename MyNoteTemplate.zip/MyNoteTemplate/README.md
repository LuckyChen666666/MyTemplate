# 1 编译环境

`Windows` + `TeX Live 2021` + `XeLaTeX` + `TeXstudio`.

# 2 导言区

1. 所有定理类环境按章编号且共享编号;
2. 公式与图表按章编号;
3. 中文的默认字体为宋体, 加粗后为黑体, 加斜后为楷体;
4. 图片记得放在文件夹`图片`里面. 

# 3 定理类环境

## 3.1 不带彩色框框的定理类环境

```latex
\begin{dl}
    这是定理环境. 
\end{dl}
```

```latex
\begin{mt}
    这是命题环境. 
\end{mt}
```

```latex
\begin{yl}
    这是引理环境. 
\end{yl}
```

```latex
\begin{tl}
    这是推论环境. 
\end{tl}
```

```latex
\begin{li}
    这是例题环境. 
\end{li}
```

```latex
\begin{dy}
    这是定义环境. 
\end{dy}
```

```latex
\begin{xz}
    这是性质环境. 
\end{xz}
```

```latex
\begin{zhu}
    这是注环境. 
\end{zhu}
```

```latex
\begin{jie}
    这是解环境. 
\end{jie}
```

```latex
\begin{zm}
    这是证明环境. 
\end{zm}
```

## 带彩色框框的定理类环境

![带彩色框框的定理类环境示例](https://s21.ax1x.com/2024/11/24/pAhVxWq.png)

对于结论型的环境 (如定理、命题、引理、推论、性质等), 提供了另一种彩色框框环境, 为此只需在相应的环境名前加个`b` (代表`blue`) 即可. 具体而言代码如下: 

```latex
\begin{bdl}
    这是定理环境. 
\end{bdl}
```

```latex
\begin{bmt}
    这是命题环境. 
\end{bmt}
```

```latex
\begin{byl}
    这是引理环境. 
\end{byl}
```

```latex
\begin{btl}
    这是推论环境. 
\end{btl}
```

```latex
\begin{bxz}
    这是性质环境. 
\end{bxz}
```